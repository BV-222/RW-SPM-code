\name{RW.MTCCT}
\alias{RW.MTCCT}
%- Also NEED an '\alias' for EACH other topic documented here.
\title{
Modified Truncated Cauchy Combination Test
}
\description{
The modified truncated cauchy combination test (MTCCT) is designed to identify spatially contiguous regions where multiple adjacent subregions exhibit moderate but collectively meaningful associations.
}
\usage{
RW.MTCCT(pvalue, num.region.r, num.region.c, threshold = 0.05)
}
%- maybe also 'usage' for other objects documented here.
\arguments{
  \item{pvalue}{A vector that contains the p-values corresponding to all subregions.}
  \item{num.region.r}{Number of regions in each row after regional partitioning.}
  \item{num.region.c}{Number of regions in each column after regional partitioning.}
  \item{threshold}{ Primary siginificant threshold.}
}
\details{
%%  ~~ If necessary, more details than the description above ~~
}
\value{
\item{rw.mtcct}{the p-value for the test.}
%%  ~Describe the value returned
%%  If it is a LIST, use
%%  \item{comp1 }{Description of 'comp1'}
%%  \item{comp2 }{Description of 'comp2'}
%% ...
}
\references{
%% ~put references to the literature/web site here ~
}
\author{
%%  ~~who you are~~
}
\note{
%%  ~~further notes~~
}

%% ~Make other sections like Warning with \section{Warning }{....} ~

\seealso{
%% ~~objects to See Also as \code{\link{help}}, ~~~
}
\examples{

# Setting the most significant cluster
pvals <- runif(126,0,1)
pvals[c(31,32,33,40,41,42,49,50,51)] = c(0.04,0.02,0.04,0.005, 10^-5, 0.005,0.04,0.02,0.04)
rw.mtcct <- RW.MTCCT(pvals, 9, 14, threshold = 0.05)
rw.mtcct
}
% Add one or more standard keywords, see file 'KEYWORDS' in the
% R documentation directory (show via RShowDoc("KEYWORDS")):
% \keyword{ ~kwd1 }
% \keyword{ ~kwd2 }
% Use only one keyword per line.
% For non-standard keywords, use \concept instead of \keyword:
% \concept{ ~cpt1 }
% \concept{ ~cpt2 }
% Use only one concept per line.

\name{RWSPM}
\alias{RWSPM}
%- Also NEED an '\alias' for EACH other topic documented here.
\title{
RegionWise Statistical Parametric Mapping
}
\description{
RegionWise statistical parametric mapping performs Regional Partitioning, distribution Aggregation within each sub-region, and Region-wise Independence Test.
}

\usage{
RWSPM(x, y, M1, M2, window.width = NA, method = "bcov")
}
%- maybe also 'usage' for other objects documented here.
\arguments{
  \item{x}{A numeric vector.}
  \item{y}{A matrix or data frame (e.g., an image) of dimension \eqn{n \times p} .}
  \item{M1}{The height of each subject (e.g., image).}
  \item{M2}{The width of each subject (e.g., image); note that \eqn{M1 \times M2 = p}.}
  \item{window.width}{Width of sliding window.}
  \item{method}{Selected test statistic ("bcov", "dcov")}
}
\details{
%%  ~~ If necessary, more details than the description above ~~
}
\value{
%%  ~Describe the value returned
%%  If it is a LIST, use
%%  \item{comp1 }{Description of 'comp1'}
%%  \item{comp2 }{Description of 'comp2'}
%% ...
\item{rw.pvalue}{ A matrix in which the first column contains the indices of the sub-regions, the second column records the corresponding test statistics, and the third column provides the associated p-values.}
\item{num.region.r}{Number of regions in each row after Regional Partitioning.}
\item{num.region.c}{Number of regions in each column after Regional Partitioning.}
}
\references{
%% ~put references to the literature/web site here ~
}
\author{
%%  ~~who you are~~
}
\note{
%%  ~~further notes~~
}

%% ~Make other sections like Warning with \section{Warning }{....} ~

\seealso{
%% ~~objects to See Also as \code{\link{help}}, ~~~
\code{\link{RW.MTCCT}}
}
\examples{
## -----------------------------
## parameter setting
## -----------------------------
n <- 200
a0 <- 0.25
sigma <- 1
M1 <- 150
M2 <- 100
M  <- M1 * M2
## affected region
c0 <- 50           # center c
r0 <- 5            # radius
sigma_r <- 1       # radius noise


## -----------------------------
## construct epsilon (n × M)
## -----------------------------
xi_10 <- rnorm(n)
xi_1 <- sign(xi_10) * (abs(xi_10) - floor(abs(xi_10)))
xi_2 <- sqrt(1 - xi_1^2) * (rbinom(n, 1, 0.5) * 2 - 1)
epsilon <- matrix(0, nrow = n, ncol = M)
for (i in 1:n) {
  base <- matrix(0, M1, M2)
  for (x in 1:M1) {
    for (y in 1:M2) {
      psi_1 <- sqrt(2) * sin(2 * pi * (x) / M1)
      psi_2 <- sqrt(2) * cos(2 * pi * (y) / M2)
      base[x, y] <- xi_1[i] * psi_1 + xi_2[i] * psi_2
    }
  }
  epsilon[i, ] <- as.vector(base)
}

## -----------------------------
## covariates
## -----------------------------
Z1 <- runif(n, min = 50, max = 100)
Z2 <- rbinom(n, 1, 0.5)

## -----------------------------
## predictor
## -----------------------------
X <- matrix(rbinom(n, 2, 0.2), ncol = 1)

## -----------------------------
## response
## -----------------------------
prod <- matrix(0, nrow = n, ncol = M)

## region center & radius
c1 <- c0 + round(rnorm(n, sd = sigma))
c2 <- c0 + round(rnorm(n, sd = sigma))
r  <- (r0 + sigma_r * rnorm(n)) * X[,1] + Z1 / 100 + Z2

## square grid around region
gp1 <- (c0 - 10):(c0 + 10)
gp2 <- (c0 - 10):(c0 + 10)

for (i in 1:n) {
  idx <- matrix(0, M1, M2)
  for (x in gp1) {
    for (y in gp2) {
      if ((x - c1[i])^2 + (y - c2[i])^2 <= r[i]^2) {
        beta <- 0.8 * exp(-0.1 * sqrt((x - c1[i])^2 + (y - c2[i])^2))
        idx[x, y] <- (X[i,1] * beta)^2 + 0.01 * Z1[i] + 0.25 * Z2[i]
      }
    }
  }
  prod[i, ] <- as.vector(idx)
}

Y <- prod + epsilon

## -----------------------------
## RegionWise statistical parametric mapping
## -----------------------------
rw.pvalue = RWSPM(x = X, y = Y, M1 = 150, M2 = 100, window.width = 20)
head(rw.pvalue$rw.pvalue)

## -----------------------------
## Modified Truncated Cauchy Combination Test on the most significant cluster
## -----------------------------
rw.mtcct <- RW.MTCCT(rw.pvalue$rw.pvalue, rw.pvalue$num.region.r, rw.pvalue$num.region.c, threshold = 0.05)
rw.mtcct
}
% Add one or more standard keywords, see file 'KEYWORDS' in the
% R documentation directory (show via RShowDoc("KEYWORDS")):
% \keyword{ ~kwd1 }
% \keyword{ ~kwd2 }
% Use only one keyword per line.
% For non-standard keywords, use \concept instead of \keyword:
% \concept{ ~cpt1 }
% \concept{ ~cpt2 }
% Use only one concept per line.
